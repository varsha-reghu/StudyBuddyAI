from sentence_transformers import SentenceTransformer, util
import os

class StudyTipRetriever:
    def __init__(self, tip_file_path):
        self.model = SentenceTransformer('all-MiniLM-L6-v2')

        if not os.path.exists(tip_file_path):
            raise FileNotFoundError(f"Study tips file not found at: {tip_file_path}")

        with open(tip_file_path, 'r', encoding='utf-8') as f:
            self.tips = [line.strip() for line in f if line.strip()]

        self.embeddings = self.model.encode(self.tips, convert_to_tensor=True)

    def get_tip(self, query):
        query_embedding = self.model.encode(query, convert_to_tensor=True)
        similarity_scores = util.pytorch_cos_sim(query_embedding, self.embeddings)
        top_tip_index = similarity_scores.argmax().item()
        return self.tips[top_tip_index]
