def generate_schedule(subjects):
    base_hours_map = {
        'low': 4,
        'medium': 2,
        'high': 1
    }

    summary = []

    for subject in subjects:
        confidence = subject['confidence'].lower()
        days_left = subject['exam_days_left']
        base_hours = base_hours_map.get(confidence, 2)

        total_hours = base_hours * days_left
        hours_per_day = round(total_hours / days_left, 1)

        summary.append({
            'subject': subject['name'].capitalize(),
            'days_left': days_left,
            'total_hours': total_hours,
            'hours_per_day': hours_per_day
        })

    return summary
